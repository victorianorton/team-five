__author__ = 'Victoria'

import sqlite3


class AddressBookDB:
    def __init__(self, conn):
        self.conn = conn
        self.cur = self.conn.cursor()

    def _query(self, q="""SELECT fname, lname from master"""):
        self.cur.execute(q)
        return self.cur.fetchall()

    def search_tb(self, name):
        print(name)
        self.cur.execute("select * from master where (fname like '%"+ name +"%' or lname like '%"+ name+
                         "%' or email like '%"+ name +"%' or zip like '%"+ name +"%' or phone_number like '%"+ name+
                         "%' or city like '%"+ name+ "%' or state like '%"+ name+ "%' or address_line_one like '%"+
                         name+ "%' or address_line_two like '%"+ name+ "%')")
        return self.cur.fetchall()

    def insert_tb(self, data):
        self.cur.execute('select max(unique_id) from master')
        uid = self.cur.fetchone()[0] + 1
        print(data)
        data = (uid,) + data
        print(data)
        self.cur.execute('insert into master values (?,?,?,?,?,?,?,?,?,?,?,?,?)', data)
        self.conn.commit()
        '''
    def insert_people(self, items):
        self.cur.execute('select max(unique_id) from master')
        uid = self.cur.fetchone()[0] + 1
        items = (uid,) + items
        self.cur.execute('insert into master values (?,?,?)', items)
        self.conn.commit()'''

    def delete_person(self, uid):
        del_ppl = (uid,)
        self.cur.execute('delete from master where unique_id = ?', del_ppl)
        self.conn.commit()

    def insert_email(self, items):
        self.cur.execute('select max(unique_id) from master')
        uid = self.cur.fetchone()[0] + 1
        # self.cur.execute('select p.unique_id, e.unique_id from people p, email e where p.unique_id = e.unique_id')
        items = (uid,) + items
        self.cur.execute('insert into master values (?,?,?)', items)
       # self.cur.execute('insert into email values (?,?)', items)
        self.conn.commit()

    def delete_email(self, uid):
        del_email = (uid,)
        self.cur.execute('delete from master where unique_id = ?', del_email)
        self.conn.commit()

    def update_email(self, uid, email):
        up_email = (uid,)
        # self.conn.execute('select p.fname, p.lname from people p join email e on p.unique_id = e.unique_id')

        self.conn.execute('UPDATE master SET email = ? '
                          'WHERE unique_id = ?', (email, up_email))
        self.conn.commit()

    def insert_phone(self, items):
        self.cur.execute('select max(unique_id) from people')
        uid = self.cur.fetchone()[0] + 1
        items = (uid,) + items
        self.cur.execute('insert into master values (?,?)', items)
        self.conn.commit()

    def delete_phone(self, uid):
        del_phone = (uid,)
        self.cur.execute('delete from master where unique_id = ?', del_phone)
        self.conn.commit()

    def search_phone(self, name):
            print(name)
            self.cur.execute("select * from master where phone_number like '%"+ name +"%'")
            return self.cur.fetchall()

    def insert_address(self, items):
        self.cur.execute('select max(unique_id) from people')
        uid = self.cur.fetchone()[0] + 1
        items = (uid,) + items
        self.cur.execute('insert into master values (?,?,?,?,?,?)', items)
        self.conn.commit()

    def delete_address(self, uid):
        del_address = (uid,)
        self.cur.execute('delete from master where unique_id = ?', del_address)
        self.conn.commit()

    def sorting_by_zip(self):
        self.cur.execute("select * from master order by zip asc")
        self.conn.commit()

    def sort_by_name(self):
        self.cur.execute("select * from master order by fname asc")
        self.conn.commit()

    def add_user_feild(self, field):
        print(field)
        self.cur.execute("alter table master add column  '%"+ field +"%'TEXT")
        self.conn.commit()

    def email_editor(self, uid, email):
        email_edit = (uid,)
        print(email_edit)
        self.cur.execute('UPDATE master SET email = ? WHERE unique_id = ?', (email, email_edit))
        self.conn.commit()

    def address_editor(self, uid, line_one, line_two, city, state, zip):
        address_edit = (uid,)
        print(address_edit)
        self.conn.execute('UPDATE master SET address_line_one = ?, address_line_two = ?, '
                     'city = ?, state = ?, zip = ?, type = ? '
                     'WHERE unique_id = ?', (line_one, line_two, city, state, zip, uid))
        self.conn.commit()

    def name_editor(self, uid, fname, lname):
        name_edit = (uid,)
        self.onn.execute('UPDATE master SET fname = ?, lname = ? WHERE unique_id = ?', (fname, lname, name_edit))
        self.conn.commit()

    def phone_editor(self, uid, phone):
        phone_edit = (uid,)
        self.conn.execute('UPDATE master SET phone_number = ?'
                     'WHERE uid = ?', (phone, phone_edit))
        self.conn.commit()

    def edit_whole_contact(self, uid, f, l, phone, plabel, line_one, line_two, city, state, zip, alabel, email, elabel):
        whole_edit = (uid,)
        self.conn.execute('UPDATE master SET fname = ?, lname = ?, phone = ?, phone_label =?, address_line_one = ?,'
                          'address_line_two = ?,city = ?, state = ?, zip = ?, address_label = ?, email = ?, '
                          'email_label = ? where unique_id = ?bWHERE unique_id = ?',
                          (f, l, phone, plabel, line_two, city, state, zip, alabel, email, elabel, whole_edit))
        self.conn.commit()

    def close(self):
        self.conn.close()


session = AddressBookDB(sqlite3.connect('addressbook_v3.db'))
