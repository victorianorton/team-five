__author__ = 'Victoria'

from tkinter import *
from guiwidgets.listview import MultiListbox
from toolbar import _init_toolbar
import sql


class ViewContact:
    # Window showing all the contact information of a person
    def __init__(self):
        self.frame = Toplevel()
        _init_toolbar(self)
        self._init_gridbox()
        self.frm_insert_all = None
        self.frm_edit_all = None
        self.add_flag = False
        self.btn_sort_name = None
        self.btn_sort_zip = None

    def _init_gridbox(self):
        self.mlb = MultiListbox(self.frame, (('uid', 3), ('First Name', 25), ('Last Name', 25), ('Email', 25),
                                             ('Email label', 25), ('Phone number', 25), ('Phone Label', 25),
                                             ('Address Line 1', 50), ('Address Line 2', 50), ('City', 25),
                                             ('State', 25), ('Zip', 10), ('Address Label', 50)))
        tb_showall = sql.session._query('''select p.fname, p.lname, e.email, e.email_label, n.phone_number,
n.phone_label, a.address_line_one, a.address_line_two, a.city, a.state, a.zip, a.address_label from people p join
email e on p.unique_id = e.unique_id join phone_numbers n on p.unique_id = n.unique_id join addresses a on
p.unique_id = a.unique_id''')
        self.update_mlb(tb_showall)
        self.mlb.pack(expand=YES, fill=BOTH)

    # insert_people button clicked()
    def btn_add_click(self):
        if self.add_flag:
            return 0
        self.add_flag = True
        self.frm_showall = ViewContact()
        self.frame.wait_window(self.frm_showall.frame)
        if self.frm_showall._okbtn_clicked == 1:
            tbShowall = sql.session._query("select p.fname, p.lname, e.email, e.email_label, n.phone_number, "
                                           "n.phone_label, a.address_line_one, a.address_line_two, a.city, a.state, "
                                           "a.zip, a.address_label from people p join email e on p.unique_id = e.unique_id join phone_numbers n"
                                           "on p.unique_id = n.unique_id join addresses a on p.unique_id = a.unique_id")
            self.update_mlb(tbShowall)
        self.add_flag = False

    def btn_edit_click(self):
        print('edit')
        sql.session.show_all()

    # delete_people button clicked()
    def btn_del_click(self):
        if self.mlb.item_selected == None:
            return 'please select first'
        print(self.mlb.item_selected[1])
        sql.session.delete_all(int(self.mlb.item_selected[1]))
        self.mlb.delete(self.mlb.item_selected[0])
        self.mlb.item_selected = None

    def btn_search_click(self):
        fnd = self.entryfind.get()

        tb_showall = sql.session.show_all(fnd)
        self.update_mlb(tb_showall)

    def update_mlb(self, tb):
        self.mlb.delete(0, END)
        for row in tb:
            self.mlb.insert(END, (int(row[0]), row[1], row[2]), row[3], row[4], row[5], row[6], row[7], row[8], row[9],
                            row[10], row[11], row[12])

    def btn_sort_name_click(self):
        print("sort me name!")

    def btn_sort_zip_click(self):
        print("sort me zip!")

    '''
class ViewContact:
    # Add new person labels and textboxes and an okay button
    def __init__(self):
        self.frame = Toplevel()
        self.frame.protocol("WM_DELETE_WINDOW", self.callback)
        #self._init_widgets()

    def _init_widgets(self):

        self.label1 = Label(self.frame, text="UID ")
        self.label1.grid(row=0, sticky=W)
        self.entry1 = Entry(self.frame)
        self.entry1.grid(row=1, column=0)


        self.label2 = Label(self.frame, text="First Name")
        self.label2.grid(row=0, column=1, sticky=W)
        self.entry2 = Entry(self.frame)
        self.entry2.grid(row=1, column=1)

        self.label3 = Label(self.frame, text="Last Name")
        self.label3.grid(row=2, sticky=W, columnspan=2)
        self.entry3 = Entry(self.frame)
        self.entry3.grid(row=3, sticky=W+E, columnspan=2)

        self.btn_ok = Button(self.frame, text="OK", width=7, command=self.btnok_click)

    def btnok_click(self):
       # items = (self.entry2.get(), self.entry3.get())
        #items = (self.entry2.get(), self.entry3.get())
        #if '' in items:
       #     print('please fill all boxes')
       #     return 'break'
        sql.session.show_all()

        self._okbtn_clicked = 1

        print('user exits the screen by clicking ok button')
        self.frame.destroy()

    def callback(self):

        self._okbtn_clicked = 0
        print('user exits the screen')
        self.frame.destroy()
        '''