import gui
root = gui.Tk()
root['bg'] = 'black'
frmmenu = gui.FormMenu(root)
frmmenu._init_widgets()
root.mainloop()
